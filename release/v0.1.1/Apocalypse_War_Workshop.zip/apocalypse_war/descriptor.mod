name="Apocalypse War"
version="0.1.1"
tags={
	"Gameplay"
	"Galaxy"
}
picture="thumbnail.png"
supported_version="v4.6.0"
remote_file_id="3840444777"