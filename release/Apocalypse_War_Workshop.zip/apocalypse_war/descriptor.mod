name="Apocalypse War"
version="0.1.0"
tags={
	"Gameplay"
	"Galaxy"
}
picture="thumbnail.png"
supported_version="v4.5.*"
remote_file_id="3840444777"